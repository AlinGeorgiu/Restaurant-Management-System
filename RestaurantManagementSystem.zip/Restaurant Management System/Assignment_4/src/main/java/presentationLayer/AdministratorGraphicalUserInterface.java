package presentationLayer;
import java.awt.Color;

import java.awt.Font;
import java.awt.TextArea;
import java.awt.event.ActionListener;
import java.util.HashSet;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import businessLayer.IRestaurantProcessing;
import businessLayer.MenuItem;
import businessLayer.Restaurant;
/**
* @author  Georgiu Alin-Ionel
* @version 1.0
* @since   2020-05-13 
*/
@SuppressWarnings("serial")
public class AdministratorGraphicalUserInterface extends JFrame{

	private JComboBox<MenuItem> createBox, deleteBox, editBox;
	private JButton createMenuItemBtn, createItemBtn, deleteItemBtn;
	private JButton editItemBtn, returnBtn, addBtn;
	private JTable table;
	private IRestaurantProcessing restaurant;
	private JTextField createMenuNameField, createNameField, createPriceField;
	private JTextField editNameField, editPriceField;
	private TextArea textBox;

	public void initialize() {
		getContentPane().setBackground(new Color(153, 204, 102));
		setFont(new Font("Rockwell", Font.PLAIN, 14));
		setTitle("Admin");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		this.setBounds(100, 100, 921, 634);
	}
	
	public void createButtons() {
		createMenuItemBtn = new JButton("Create Menu");
		createMenuItemBtn.setFont(new Font("Rockwell Condensed", Font.PLAIN, 17));
		createMenuItemBtn.setBackground(new Color(255, 204, 102));
		createMenuItemBtn.setBounds(10, 261, 123, 31);
		getContentPane().add(createMenuItemBtn);

		deleteItemBtn = new JButton("Delete");
		deleteItemBtn.setFont(new Font("Rockwell Condensed", Font.PLAIN, 17));
		deleteItemBtn.setBackground(new Color(255, 204, 102));
		deleteItemBtn.setBounds(332, 547, 228, 31);
		getContentPane().add(deleteItemBtn);

		editItemBtn = new JButton("Edit Menu ");
		editItemBtn.setFont(new Font("Rockwell Condensed", Font.PLAIN, 17));
		editItemBtn.setBackground(new Color(255, 204, 102));
		editItemBtn.setBounds(527, 305, 126, 29);
		getContentPane().add(editItemBtn);

		returnBtn = new JButton("Return Home");
		returnBtn.setFont(new Font("Rockwell Condensed", Font.PLAIN, 17));
		returnBtn.setBackground(new Color(153, 204, 204));
		returnBtn.setBounds(706, 547, 191, 31);
		getContentPane().add(returnBtn);
		
		createItemBtn = new JButton("Create Item");
		createItemBtn.setFont(new Font("Rockwell Condensed", Font.PLAIN, 17));
		createItemBtn.setBackground(new Color(255, 204, 102));
		createItemBtn.setBounds(527, 111, 126, 30);
		getContentPane().add(createItemBtn);
		
		addBtn = new JButton("ADD");
		addBtn.setBackground(new Color(255, 204, 102));
		addBtn.setFont(new Font("Rockwell Condensed", Font.PLAIN, 17));
		addBtn.setBounds(10, 111, 123, 25);
		getContentPane().add(addBtn);
	}
	
	public void createLabels() {
		JLabel createItemLabel = new JLabel("Add Item To Menu");
		createItemLabel.setFont(new Font("Rockwell", Font.PLAIN, 20));
		createItemLabel.setBounds(61, 10, 177, 28);
		getContentPane().add(createItemLabel);

		textBox = new TextArea();
		textBox.setBounds(10, 145, 288, 110);
		getContentPane().add(textBox);

		JLabel deleteItemLabel = new JLabel("Delete Item From Menu");
		deleteItemLabel.setFont(new Font("Rockwell", Font.PLAIN, 20));
		deleteItemLabel.setBounds(332, 446, 217, 22);
		getContentPane().add(deleteItemLabel);

		JLabel editItemLabel = new JLabel("Edit Item");
		editItemLabel.setFont(new Font("Rockwell", Font.PLAIN, 20));
		editItemLabel.setBounds(605, 165, 135, 22);
		getContentPane().add(editItemLabel);

		createMenuNameField = new JTextField();
		createMenuNameField.setBounds(61, 48, 191, 22);
		getContentPane().add(createMenuNameField);
		createMenuNameField.setColumns(10);

		JLabel nameLabel = new JLabel("Name :");
		nameLabel.setFont(new Font("Rockwell Condensed", Font.PLAIN, 17));
		nameLabel.setBounds(10, 48, 61, 16);
		getContentPane().add(nameLabel);

		JLabel productsLabel = new JLabel("Items :");
		productsLabel.setFont(new Font("Rockwell Condensed", Font.PLAIN, 17));
		productsLabel.setBounds(10, 86, 61, 15);
		getContentPane().add(productsLabel);

		JLabel createLabel = new JLabel("Create Item");
		createLabel.setFont(new Font("Rockwell", Font.PLAIN, 20));
		createLabel.setBounds(605, 9, 113, 31);
		getContentPane().add(createLabel);

		createNameField = new JTextField();
		createNameField.setBounds(574, 48, 187, 22);
		getContentPane().add(createNameField);
		createNameField.setColumns(10);

		JLabel nameLabel2 = new JLabel("Name :");
		nameLabel2.setFont(new Font("Rockwell Condensed", Font.PLAIN, 17));
		nameLabel2.setBounds(527, 48, 61, 16);
		getContentPane().add(nameLabel2);

		JLabel priceLabel = new JLabel("Price :");
		priceLabel.setFont(new Font("Rockwell Condensed", Font.PLAIN, 17));
		priceLabel.setBounds(527, 79, 58, 22);
		getContentPane().add(priceLabel);

		createPriceField = new JTextField();
		createPriceField.setColumns(10);
		createPriceField.setBounds(574, 80, 187, 22);
		getContentPane().add(createPriceField);

		editNameField = new JTextField();
		editNameField.setColumns(10);
		editNameField.setBounds(574, 234, 187, 22);
		getContentPane().add(editNameField);

		JLabel nameLabel3 = new JLabel("Name :");
		nameLabel3.setFont(new Font("Rockwell Condensed", Font.PLAIN, 17));
		nameLabel3.setBounds(527, 234, 47, 22);
		getContentPane().add(nameLabel3);

		editPriceField = new JTextField();
		editPriceField.setColumns(10);
		editPriceField.setBounds(574, 261, 187, 22);
		getContentPane().add(editPriceField);

		JLabel priceLabel2 = new JLabel("Price :");
		priceLabel2.setFont(new Font("Rockwell Condensed", Font.PLAIN, 17));
		priceLabel2.setBounds(527, 262, 58, 23);
		getContentPane().add(priceLabel2);
	}
	
	public AdministratorGraphicalUserInterface(IRestaurantProcessing restaurant) {
		this.restaurant = restaurant;
		initialize();

		table = new JTable();
		table.setFont(new Font("Rockwell", Font.PLAIN, 13));
		table.setBackground(new Color(255, 228, 225));
		showTable((Restaurant) restaurant);
		table.setBounds(437, 353, 222, -262);
		
		createButtons();

		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(10, 329, 288, 258);
		getContentPane().add(scrollPane);

		JLabel lblMenu = new JLabel("Menu");
		lblMenu.setFont(new Font("Rockwell", Font.PLAIN, 24));
		lblMenu.setBounds(121, 290, 97, 31);
		getContentPane().add(lblMenu);

		createBox = new JComboBox<MenuItem>();
		deleteBox = new JComboBox<MenuItem>();
		deleteBox.setBackground(new Color(204, 204, 102));
		deleteBox.setBounds(332, 481, 217, 27);
		editBox = new JComboBox<MenuItem>();
		editBox.setBackground(new Color(204, 204, 102));
		editBox.setBounds(527, 197, 217, 27);

		for (MenuItem item : ((Restaurant) restaurant).getMenu()) {
			createBox.addItem(item);
			editBox.addItem(item);
			deleteBox.addItem(item);
		}
		createBox.setBounds(61, 79, 191, 22);
		getContentPane().add(createBox);
		getContentPane().add(deleteBox);
		getContentPane().add(editBox);

		createLabels();

		
	}
	
	public void createMenuProduct(ActionListener actionListener) {
		createMenuItemBtn.addActionListener(actionListener);
	}

	public void addCreateMenuProductBtn(ActionListener actionListener) {
		createItemBtn.addActionListener(actionListener);
	}

	public void addDeteleMenuItemBtn(ActionListener actionListener) {
		deleteItemBtn.addActionListener(actionListener);
	}

	public void addEditMenuProductBtn(ActionListener actionListener) {
		editItemBtn.addActionListener(actionListener);
	}

	public void addReturnHomeBtn(ActionListener actionListener) {
		returnBtn.addActionListener(actionListener);
	}

	public void addBtnADD(ActionListener actionListener) {
		addBtn.addActionListener(actionListener);
	}

	public String getCreateMenuName() {
		return createMenuNameField.getText();
	}

	public String getItemName() {
		return createNameField.getText();
	}

	public String getProductPrice() {
		return createPriceField.getText();
	}

	public String getEditNameField() {
		return editNameField.getText();
	}

	public int getEditPriceField() {
		return Integer.parseInt(editPriceField.getText());
	}

	public JComboBox<MenuItem> createMenuBox() {
		return createBox;
	}

	public MenuItem createBoxProduct() {
		return (MenuItem) createBox.getSelectedItem();
	}

	public JComboBox<MenuItem> getDeleteMenuBox() {
		return deleteBox;
	}

	public JComboBox<MenuItem> getEditMenuBox() {
		return editBox;
	}

	public MenuItem getDeleteProductComboBox() {
		return (MenuItem) deleteBox.getSelectedItem();
	}

	public MenuItem getEditProductBox() {
		return (MenuItem) editBox.getSelectedItem();
	}

	public void getTextArea(MenuItem item) {
		textBox.append(" \n" + item.toString());
	}

	public void updateMenuBox(JComboBox<MenuItem> box) {
		box.removeAllItems();
		for (MenuItem c : ((Restaurant) restaurant).getMenu()) {
			box.addItem(c);
		}
		getContentPane().add(box);
		getContentPane().revalidate();
		getContentPane().repaint();
	}

	public IRestaurantProcessing getRestaurant() {
		return restaurant;
	}

	public void setRestaurant(IRestaurantProcessing restaurant) {
		this.restaurant = restaurant;
	}

	public void displayMessage(final String message) {
		JOptionPane.showMessageDialog(this, message);
	}
	
	public void showTable(Restaurant restaurant) {

		HashSet<MenuItem> menu;
		Object[] names = new Object[3];
		Object[] data = new Object[3];
		DefaultTableModel model = new DefaultTableModel();
		
		names[0] = "Id :";
		names[1] = "Name :";
		names[2] = "Price :";
		
		table.setModel(
				new DefaultTableModel(new Object[][] { { null, null, null }, { null, null, null }, { null, null, null },
						{ null, null, null }, { null, null, null }, }, new String[] { "Id :", "Name :", "Price :" }));

		menu = restaurant.getMenu();		
		model.setColumnIdentifiers(names);

		for (MenuItem item : menu) {
			data[0] = item.getID();
			data[1] = item.getName();
			data[2] = item.computePrice();
			model.addRow(data);
		}
		table.setModel(model);
	}
}
