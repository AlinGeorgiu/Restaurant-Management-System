package presentationLayer;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
/**
* @author  Georgiu Alin-Ionel
* @version 1.0
* @since   2020-05-13 
*/
@SuppressWarnings("serial")
public class MainGUI extends JFrame{
	
	JButton adminBtn, chefBtn, waiterBtn;
	
	
	public MainGUI() {
		getContentPane().setBackground(new Color(102, 205, 170));
		setFont(new Font("Sylfaen", Font.PLAIN, 14));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Restaurant");
		getContentPane().setLayout(null);

		setButtons();

		JLabel welcomeLabel = new JLabel("Welcome to the G's Restaurant");
		welcomeLabel.setFont(new Font("SimSun", Font.BOLD, 25));
		welcomeLabel.setBounds(236, 28, 544, 34);
		getContentPane().add(welcomeLabel);
		this.setBounds(100, 100, 842, 426);
	}
	
	public void setButtons() {
		adminBtn = new JButton("Admin");
		adminBtn.setFont(new Font("Sylfaen", Font.BOLD | Font.ITALIC, 22));
		adminBtn.setBackground(new Color(255, 218, 185));
		adminBtn.setBounds(306, 86, 230, 67);
		getContentPane().add(adminBtn);

		chefBtn = new JButton("Chef");
		chefBtn.setFont(new Font("Sylfaen", Font.BOLD | Font.ITALIC, 22));
		chefBtn.setBackground(new Color(255, 218, 185));
		chefBtn.setBounds(306, 176, 230, 67);
		getContentPane().add(chefBtn);

		waiterBtn = new JButton("Waiter");
		waiterBtn.setFont(new Font("Sylfaen", Font.BOLD | Font.ITALIC, 22));
		waiterBtn.setBackground(new Color(255, 218, 185));
		waiterBtn.setBounds(306, 269, 230, 63);
		getContentPane().add(waiterBtn);
	}
	

	public void addBtnAdminSectionActionListener(ActionListener actionListener) {
		adminBtn.addActionListener(actionListener);
	}

	public void addWaiterBtn(ActionListener actionListener) {
		waiterBtn.addActionListener(actionListener);
	}
	
	public void addChefBtn(ActionListener actionListener) {
		chefBtn.addActionListener(actionListener);
	}
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainGUI mainWindow = new MainGUI();
					mainWindow.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
