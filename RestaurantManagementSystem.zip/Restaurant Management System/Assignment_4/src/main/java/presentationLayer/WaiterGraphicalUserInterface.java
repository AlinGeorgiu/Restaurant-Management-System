package presentationLayer;

import java.awt.Color;
import java.awt.Font;
import java.awt.TextArea;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import businessLayer.IRestaurantProcessing;
import businessLayer.MenuItem;
import businessLayer.Order;
import businessLayer.Restaurant;
/**
* @author  Georgiu Alin-Ionel
* @version 1.0
* @since   2020-05-13 
*/
@SuppressWarnings("serial")
public class WaiterGraphicalUserInterface extends JFrame{

	private IRestaurantProcessing restaurant;
	private JTextArea text;
	private JButton generateBillBtn, computePriceBtn, createOrderBtn, returnHomeBtn, addBtn, deleteBtn;
	private TextArea productsOrdered;
	private JComboBox<MenuItem> addOrderBox;
	private JComboBox<Order> generateBillBox, costBox;
	private List<Order> acutalOrders = new ArrayList<Order>();
	private JTextField priceOfOrders, tableField;
	private JLabel lblAddTable;
	
	public void createButtons() {
		generateBillBtn = new JButton("Generate");
		generateBillBtn.setFont(new Font("Rockwell Condensed", Font.PLAIN, 22));
		generateBillBtn.setBackground(new Color(153, 204, 204));
		generateBillBtn.setBounds(979, 369, 129, 30);
		getContentPane().add(generateBillBtn);

		computePriceBtn = new JButton("Compute");
		computePriceBtn.setFont(new Font("Rockwell Condensed", Font.PLAIN, 22));
		computePriceBtn.setBackground(new Color(153, 204, 204));
		computePriceBtn.setBounds(865, 92, 123, 30);
		getContentPane().add(computePriceBtn);

		createOrderBtn = new JButton("Create");
		createOrderBtn.setFont(new Font("Rockwell Condensed", Font.PLAIN, 22));
		createOrderBtn.setBackground(new Color(153, 204, 204));
		createOrderBtn.setBounds(382, 316, 105, 33);
		getContentPane().add(createOrderBtn);

		returnHomeBtn = new JButton("Return Home");
		returnHomeBtn.setFont(new Font("Rockwell Condensed", Font.PLAIN, 22));
		returnHomeBtn.setBackground(new Color(51, 204, 153));
		returnHomeBtn.setBounds(1068, 519, 174, 33);
		getContentPane().add(returnHomeBtn);
		
		addBtn = new JButton("add");
		addBtn.setBackground(new Color(153, 204, 204));
		addBtn.setFont(new Font("Rockwell Condensed", Font.PLAIN, 17));
		addBtn.setBounds(599, 53, 91, 27);
		getContentPane().add(addBtn);
		
		deleteBtn = new JButton("delete");
		deleteBtn.setBackground(new Color(153, 204, 204));
		deleteBtn.setFont(new Font("Rockwell Condensed", Font.PLAIN, 17));
		deleteBtn.setBounds(696, 190, 105, 30);
		getContentPane().add(deleteBtn);
	}
	
	public WaiterGraphicalUserInterface(IRestaurantProcessing restaurant) {
		getContentPane().setFont(new Font("Rockwell", Font.PLAIN, 12));
		this.restaurant = restaurant;
		getContentPane().setBackground(new Color(153, 204, 153));
		setFont(new Font("Rockwell", Font.PLAIN, 16));
		setTitle("Waiter ");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		createButtons();
		
		this.setBounds(100, 100, 1266, 599);
		JScrollPane scrollingPane = new JScrollPane(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		scrollingPane.setBounds(10, 72, 270, 416);
		getContentPane().add(scrollingPane);
		
		text = new JTextArea();
		text.setFont(new Font("Rockwell", Font.PLAIN, 14));
		scrollingPane.setViewportView(text);
		text.setWrapStyleWord(true);

		JLabel tablesLbl = new JLabel("Tables ");
		tablesLbl.setFont(new Font("Rockwell", Font.PLAIN, 22));
		tablesLbl.setHorizontalAlignment(SwingConstants.LEFT);
		tablesLbl.setBounds(97, 24, 77, 38);
		getContentPane().add(tablesLbl);
		
		JLabel productsLabel = new JLabel("Add products to order");
		productsLabel.setFont(new Font("Rockwell Condensed", Font.PLAIN, 22));
		productsLabel.setBounds(447, 10, 192, 30);
		getContentPane().add(productsLabel);
		
		JLabel checkoutLabel = new JLabel("Checkout");
		checkoutLabel.setFont(new Font("Rockwell Condensed", Font.PLAIN, 22));
		checkoutLabel.setBounds(1068, 282, 105, 31);
		getContentPane().add(checkoutLabel);

		JLabel costLabel = new JLabel("Bill Cost");
		costLabel.setFont(new Font("Rockwell Condensed", Font.PLAIN, 22));
		costLabel.setBounds(928, 10, 77, 30);
		getContentPane().add(costLabel);

		addOrderBox = new JComboBox<MenuItem>();
		addOrderBox.setFont(new Font("Sylfaen", Font.PLAIN, 12));
		addOrderBox.setBackground(new Color(204, 204, 204));
		addOrderBox.setBounds(382, 50, 213, 30);
		for (MenuItem item : ((Restaurant) restaurant).getMenu()) {
			addOrderBox.addItem(item);
		}
		getContentPane().add(addOrderBox);

		generateBillBox = new JComboBox<Order>();
		generateBillBox.setFont(new Font("Sylfaen", Font.PLAIN, 12));
		generateBillBox.setBackground(new Color(204, 204, 204));
		generateBillBox.setBounds(979, 323, 242, 26);
		for (Order order : ((Restaurant) restaurant).getOrderedProducts().keySet()) {
			generateBillBox.addItem(order);
		}
		getContentPane().add(generateBillBox);

		costBox = new JComboBox<Order>();
		costBox.setFont(new Font("Sylfaen", Font.PLAIN, 12));
		costBox.setBackground(new Color(204, 204, 204));
		costBox.setBounds(854, 54, 242, 26);
		for (Order order : ((Restaurant) restaurant).getOrderedProducts().keySet()) {
			costBox.addItem(order);
		}
		getContentPane().add(costBox);

		priceOfOrders = new JTextField();
		priceOfOrders.setBounds(1004, 92, 92, 31);
		getContentPane().add(priceOfOrders);
		priceOfOrders.setColumns(10);

		productsOrdered = new TextArea();
		productsOrdered.setBounds(382, 105, 308, 133);
		getContentPane().add(productsOrdered);
		
		lblAddTable = new JLabel("New Table");
		lblAddTable.setFont(new Font("Rockwell Condensed", Font.PLAIN, 22));
		lblAddTable.setBounds(382, 244, 105, 33);
		getContentPane().add(lblAddTable);
		
		tableField = new JTextField();
		tableField.setColumns(10);
		tableField.setBounds(382, 282, 105, 30);
		getContentPane().add(tableField);
	}
	public void addCreateNewOrderBtn(ActionListener actionListener) {
		createOrderBtn.addActionListener(actionListener);
	}

	public void addBtnComputePriceActionListener(ActionListener actionListener) {
		computePriceBtn.addActionListener(actionListener);
	}

	public void addBtnGenerateBillActionListener(ActionListener actionListener) {
		generateBillBtn.addActionListener(actionListener);
	}

	public void addReturnHomeBtn(ActionListener actionListener) {
		returnHomeBtn.addActionListener(actionListener);
	}

	public void addADDBtn(ActionListener actionListener) {
		addBtn.addActionListener(actionListener);
	}

	public void addDeleteBtn(ActionListener actionListener) {
		deleteBtn.addActionListener(actionListener);
	}

	public MenuItem getMenuItemComboBox() {
		return (MenuItem) addOrderBox.getSelectedItem();
	}

	public JComboBox<MenuItem> getMenuComboBox() {
		return addOrderBox;
	}

	public Order getOrderToBillComboBox() {
		return (Order) generateBillBox.getSelectedItem();
	}
	
	public JComboBox<Order> getBillComboBox() {
		return generateBillBox;
	}

	public Order getOrderToComputePriceComboBox() {
		return (Order) costBox.getSelectedItem();
	}
	
	public JComboBox<Order> getComputeComboBox() {
		return costBox;
	}

	public void appendToOrderedTextArea(String s) {
		productsOrdered.append("\n" + s);
	}

	public String getOrderedTextAreaText() {
		return productsOrdered.getText();
	}
	
	public String getTableTextField() {
		return tableField.getText();
	}

	public void setOrderedTextAreaText(String s) {
		productsOrdered.setText(s);
	}

	public void setOrderPriceTextField(int price) {
		priceOfOrders.setText("" + price);
	}

	public void updateTextArea(Order o) {
		acutalOrders.add(o);
		text.append("\n" + o.toString());
	}

	public void updateMenuBox(JComboBox<MenuItem> comboBox) {
		comboBox.removeAllItems();
		for (MenuItem item : ((Restaurant) restaurant).getMenu()) {
			comboBox.addItem(item);
		}
		getContentPane().add(comboBox);
		getContentPane().revalidate();
		getContentPane().repaint();
	}

	public void updateOrderComboBox(JComboBox<Order> comboBox) {
		comboBox.removeAllItems();
		for (Order order : ((Restaurant) restaurant).getOrderedProducts().keySet()) {
			comboBox.addItem(order);
		}
		getContentPane().add(comboBox);
		getContentPane().revalidate();
		getContentPane().repaint();
	}
	
	public IRestaurantProcessing getRestaurant() {
		return restaurant;
	}

	public void setRestaurant(IRestaurantProcessing restaurant) {
		this.restaurant = restaurant;
	}
	
	public void displayMessage(final String messageText) {
		JOptionPane.showMessageDialog(this, messageText);
	}
}