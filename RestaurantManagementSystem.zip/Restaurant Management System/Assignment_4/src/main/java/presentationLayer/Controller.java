package presentationLayer;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashSet;

import businessLayer.BaseProduct;
import businessLayer.MenuItem;
import businessLayer.Order;
import businessLayer.Restaurant;
import dataLayer.RestaurantSerializator;
/**
* @author  Georgiu Alin-Ionel
* @version 1.0
* @since   2020-05-13 
*/
public class Controller {
	
	private MainGUI mainInterface;
	private AdministratorGraphicalUserInterface adminInterface;
	private WaiterGraphicalUserInterface waiterInterface;
	private ChefGraphicalUserInterface chefInterface;

	public Controller(MainGUI mainInterface, AdministratorGraphicalUserInterface adminInterface, WaiterGraphicalUserInterface waiterInterface,
			ChefGraphicalUserInterface chefInterface) {
		this.mainInterface = mainInterface;
		this.waiterInterface = waiterInterface;
		this.chefInterface = chefInterface;
		this.adminInterface = adminInterface;
	}

	public void start() {
		mainInterface.setLocationRelativeTo(null);
		mainInterface.setVisible(true);
		initializeButtonListeners();
	}

	public void refreshAdminInterfaceTable(Restaurant restaurant) {
		adminInterface.showTable(restaurant);
		adminInterface.updateMenuBox(adminInterface.createMenuBox());
		adminInterface.updateMenuBox(adminInterface.getDeleteMenuBox());
		adminInterface.updateMenuBox(adminInterface.getEditMenuBox());
		waiterInterface.updateMenuBox(waiterInterface.getMenuComboBox());
		RestaurantSerializator.serializeRestaurant(restaurant);
		adminInterface.getContentPane().revalidate();
		adminInterface.getContentPane().repaint();
		waiterInterface.getContentPane().revalidate();
		waiterInterface.getContentPane().repaint();
	}

	public void initializeButtonListeners() {
		final HashSet<MenuItem> orderedItems = new HashSet<MenuItem>();
		
		mainInterface.addBtnAdminSectionActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				adminInterface.setLocationRelativeTo(null);
				adminInterface.setVisible(true);
				mainInterface.dispose();
			}
		});
		mainInterface.addWaiterBtn(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mainInterface.dispose();
				waiterInterface.setLocationRelativeTo(null);
				waiterInterface.setVisible(true);
			}
		});

		mainInterface.addChefBtn(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mainInterface.dispose();
				chefInterface.setLocationRelativeTo(null);
				chefInterface.setVisible(true);
			}
		});
		waiterInterface.addReturnHomeBtn(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				waiterInterface.dispose();
				mainInterface.setLocationRelativeTo(null);
				mainInterface.setVisible(true);
			}
		});

		waiterInterface.addADDBtn(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					MenuItem menu = waiterInterface.getMenuItemComboBox();
					waiterInterface.appendToOrderedTextArea(menu.toString());
					orderedItems.add(menu);
				} catch (Exception e1) {
					System.err.println(e1.getMessage());
				}
			}
		});

		waiterInterface.addDeleteBtn(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
				MenuItem menu = waiterInterface.getMenuItemComboBox();
				orderedItems.remove(menu);
				waiterInterface.setOrderedTextAreaText("");
				for (MenuItem newMenu : orderedItems) {
					waiterInterface.appendToOrderedTextArea(newMenu.toString());
				}
				waiterInterface.getContentPane().revalidate();
				waiterInterface.getContentPane().repaint();
				}catch(Exception e1) {
					System.err.println(e1.getMessage());
				}
			}
		});

		waiterInterface.addCreateNewOrderBtn(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				try {
					Order order = new Order();
					int table = Integer.parseInt(waiterInterface.getTableTextField());
					Restaurant restaurant = (Restaurant) waiterInterface.getRestaurant();
					order.setTableNumber(table);
					restaurant.createNewOrder(order, orderedItems);
					RestaurantSerializator.serializeRestaurant(restaurant);
					waiterInterface.updateTextArea(order);
					waiterInterface.updateOrderComboBox(waiterInterface.getComputeComboBox());
					waiterInterface.updateOrderComboBox(waiterInterface.getBillComboBox());
					chefInterface.updateTextArea(order.toString() + restaurant.getOrderedProducts().get(order).toString());
					waiterInterface.getContentPane().revalidate();
					waiterInterface.getContentPane().repaint();
				} catch (Exception ex) {
					System.err.println(ex.getMessage());
				}
			}
		});

		waiterInterface.addBtnComputePriceActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
				Order order = waiterInterface.getOrderToComputePriceComboBox();
				Restaurant restaurant = (Restaurant) waiterInterface.getRestaurant();
				float price = restaurant.computeOrderPrice(order);
				RestaurantSerializator.serializeRestaurant(restaurant);
				waiterInterface.setOrderPriceTextField((int) price);
				waiterInterface.getContentPane().revalidate();
				waiterInterface.getContentPane().repaint();
				}catch(Exception e1) {
					System.err.println(e1.getMessage());

				}
			}
		});

		waiterInterface.addBtnGenerateBillActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
				Order order = waiterInterface.getOrderToBillComboBox();
				Restaurant restaurant = (Restaurant) waiterInterface.getRestaurant();
				RestaurantSerializator.serializeRestaurant(restaurant);
				restaurant.generateTableBill(order);
				}catch(Exception e1) {
					System.err.println(e1.getMessage());
				}
			}
		});

		adminInterface.addReturnHomeBtn(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				adminInterface.dispose();
				mainInterface.setLocationRelativeTo(null);
				mainInterface.setVisible(true);
			}
		});

		adminInterface.addCreateMenuProductBtn(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String name = adminInterface.getItemName();
					String price = adminInterface.getProductPrice();
					if (price.equals("")) {
						throw new Exception("Enter a price to continuu!");
					}
					if (name.equals("")) {
						throw new Exception("Enter a name to continuu!");
					}
					HashSet<MenuItem> element = new HashSet<MenuItem>();
					MenuItem item = new BaseProduct(name, Integer.parseInt(price));
					element.add(item);
					Restaurant restaurant = (Restaurant) adminInterface.getRestaurant();
					restaurant.createNewMenuItem(name, element);
					RestaurantSerializator.serializeRestaurant(restaurant);
					refreshAdminInterfaceTable(restaurant);
				} catch (Exception e1) {
					adminInterface.displayMessage(e1.toString());
					System.err.println(e1.getMessage());
				}
			}
		});

		final HashSet<MenuItem> components = new HashSet<MenuItem>();
		adminInterface.addBtnADD(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					MenuItem menu = adminInterface.createBoxProduct();
					adminInterface.getTextArea(menu);
					components.add(menu);
					adminInterface.getContentPane().revalidate();
					adminInterface.getContentPane().repaint();
				} catch (Exception e1) {
					System.err.println(e1.getMessage());
				}
			}
		});
		adminInterface.createMenuProduct(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String name = adminInterface.getCreateMenuName();
					if (name.equals("")) {
						throw new Exception("Please enter a name!");
					}
					Restaurant restaurant = (Restaurant) adminInterface.getRestaurant();
					restaurant.createNewMenuItem(name, components);
					RestaurantSerializator.serializeRestaurant(restaurant);
					refreshAdminInterfaceTable(restaurant);
				} catch (Exception e1) {
					adminInterface.displayMessage(e1.toString());
					System.err.println(e1.getMessage());
				}
			}
		});

		adminInterface.addDeteleMenuItemBtn(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					MenuItem menu = adminInterface.getDeleteProductComboBox();
					Restaurant restaurant = (Restaurant) adminInterface.getRestaurant();
					restaurant.deleteMenuItem(menu);
					RestaurantSerializator.serializeRestaurant(restaurant);
					refreshAdminInterfaceTable(restaurant);
				} catch (Exception e1) {
					System.err.println(e1.getMessage());
				}
			}
		});
	
		adminInterface.addEditMenuProductBtn(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					MenuItem menu = adminInterface.getEditProductBox();
					String brandNewName = adminInterface.getEditNameField();
					int brandNewPrice = adminInterface.getEditPriceField();
					MenuItem menuRefreshed = new BaseProduct(brandNewName, brandNewPrice);
					menuRefreshed.setID(menu.getID());
					Restaurant restaurant = (Restaurant) adminInterface.getRestaurant();
					restaurant.editMenuItem(menu, menuRefreshed);
					RestaurantSerializator.serializeRestaurant(restaurant);
					refreshAdminInterfaceTable(restaurant);
				} catch (Exception e1) {
					System.err.println(e1.getMessage());
				}					

			}
		});
		
		chefInterface.addReturnHomeBtn(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				chefInterface.dispose();
				mainInterface.setLocationRelativeTo(null);
				mainInterface.setVisible(true);
			}
		});
	}
}
