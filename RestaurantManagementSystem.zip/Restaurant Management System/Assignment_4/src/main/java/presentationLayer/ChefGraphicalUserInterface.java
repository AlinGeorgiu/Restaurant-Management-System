package presentationLayer;

import java.awt.Color;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.util.Observable;
import java.util.Observer;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import businessLayer.IRestaurantProcessing;
/**
* @author  Georgiu Alin-Ionel
* @version 1.0
* @since   2020-05-13 
*/
@SuppressWarnings("serial")
public class ChefGraphicalUserInterface extends JFrame implements Observer {
	private IRestaurantProcessing restaurant;
	private JButton returnHomeBtn;
	private JTextArea text;
	private JLabel dishesList;
	
	
	public ChefGraphicalUserInterface(IRestaurantProcessing restaurant) {
		getContentPane().setBackground(new Color(153, 204, 102));
		this.restaurant = restaurant;
		setFont(new Font("Rockwell", Font.PLAIN, 14));
		setTitle("Chef");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		this.setBounds(100, 100, 804, 627);

		returnHomeBtn = new JButton("Return to Home");
		returnHomeBtn.setFont(new Font("Rockwell Condensed", Font.PLAIN, 22));
		returnHomeBtn.setBackground(new Color(153, 204, 204));
		returnHomeBtn.setBounds(529, 518, 197, 35);
		getContentPane().add(returnHomeBtn);
		this.setBounds(100, 100, 750, 600);
		JScrollPane scrollingPanel = new JScrollPane(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
		JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		scrollingPanel.setBounds(10, 61, 277, 467);
		getContentPane().add(scrollingPanel);
		
		text = new JTextArea();
		scrollingPanel.setViewportView(text);
		text.setFont(new Font("Sylfaen", Font.PLAIN, 17));
		text.setBackground(new Color(204, 204, 153));
		text.setWrapStyleWord(true);
		
		dishesList = new JLabel("Dishes List");
		dishesList.setFont(new Font("Rockwell", Font.PLAIN, 25));
		dishesList.setBounds(73, 20, 125, 31);
		getContentPane().add(dishesList);
		
	}
	
	public void addReturnHomeBtn(ActionListener actionListener) {
		returnHomeBtn.addActionListener(actionListener);
	}
	
	public void updateTextArea(String string) {
		text.append( "\n" + string);
	}

	public void update(Observable arg0, Object arg1) {
		System.out.println("Chef is an observer!");
	}

	public IRestaurantProcessing getRestaurant() {
		return restaurant;
	}

	public void setRestaurant(IRestaurantProcessing restaurant) {
		this.restaurant = restaurant;
	}
}
