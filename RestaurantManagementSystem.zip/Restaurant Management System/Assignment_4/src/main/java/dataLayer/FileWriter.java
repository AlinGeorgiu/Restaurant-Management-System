package dataLayer;

import java.io.FileNotFoundException;

import java.io.PrintWriter;
import java.util.Random;

import businessLayer.MenuItem;
import businessLayer.Order;
import businessLayer.Restaurant;
/**
* @author  Georgiu Alin-Ionel
* @version 1.0
* @since   2020-05-13 
*/
public class FileWriter {

	private static int billNumber;

	public static void generateBill(Order order, Restaurant restaurant) {
		billNumber++;
        Random rand = new Random(); 
		try {
			PrintWriter textFilePrinter = new PrintWriter("billNr_" + billNumber + ".txt");
			textFilePrinter.println("#########################");
			textFilePrinter.println("   BILL SUMMARY   " + 100000 + rand.nextInt(999999999));
			textFilePrinter.println("\n #########################\n\n ");
			textFilePrinter.println("Bill Nr. " + billNumber);
			textFilePrinter.println("Table Nr." + order.getTableNumber() + " has products ");
			for (MenuItem item : restaurant.getOrderedProducts().get(order)) {
				textFilePrinter.println(item.toString() + " \n");
			}
			textFilePrinter.println("#########################");
			textFilePrinter.println("                         ###  TOTAL    " + restaurant.computeOrderPrice(order) + " RON    ###");
			textFilePrinter.close();
		} catch (FileNotFoundException e) {
			System.out.println("File not found");
		}
	}
}