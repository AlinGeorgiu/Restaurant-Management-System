package dataLayer;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import businessLayer.Restaurant;
/**
* @author  Georgiu Alin-Ionel
* @version 1.0
* @since   2020-05-13 
*/
@SuppressWarnings("serial")
public class RestaurantSerializator implements Serializable {
	private final static String filePath = "C:\\PT2020\\pt2020_30223_alin_georgiu_assignment_4\\Assignment_4/restaurant.ser";


	public static void serializeRestaurant(Restaurant restaurant) {

		try {
			FileOutputStream outFile = new FileOutputStream(filePath);
			ObjectOutputStream outStream = new ObjectOutputStream(outFile);
			outStream.writeObject(restaurant);
			outStream.close();
			outFile.close();
		} catch (Exception ex) {
			System.err.println(ex.getMessage());
		}
	}
	/**
	 * Face o copie a restaurantului si o salveaza in restaurant.ser
	 * @return Restaurant restaurant
	 * 
	 */
	public static Restaurant deserializeRestaurant() {

		Restaurant restaurant = new Restaurant();
		try {

			FileInputStream inputFile = new FileInputStream(filePath);
			ObjectInputStream inStream = new ObjectInputStream(inputFile);
			restaurant = (Restaurant) inStream.readObject();
			inStream.close();
			inputFile.close();
		} catch (Exception ex) {

			System.err.println(ex.getMessage());

		}
		return restaurant;
	}
}
