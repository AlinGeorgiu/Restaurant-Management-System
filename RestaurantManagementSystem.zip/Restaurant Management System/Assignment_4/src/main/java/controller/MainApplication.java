package controller;

import businessLayer.IRestaurantProcessing;
import dataLayer.RestaurantSerializator;
import presentationLayer.AdministratorGraphicalUserInterface;
import presentationLayer.ChefGraphicalUserInterface;
import presentationLayer.Controller;
import presentationLayer.MainGUI;
import presentationLayer.WaiterGraphicalUserInterface;
/**
* Aceasta este clasa principala de unde ruleaza programul 
*
* @author  Georgiu Alin-Ionel
* @version 1.0
* @since   2020-05-13 
*/
public class MainApplication {

	public static void main(String[] args) {
		IRestaurantProcessing restaurant = RestaurantSerializator.deserializeRestaurant();
		MainGUI MainInterface = new MainGUI();
		AdministratorGraphicalUserInterface adminInterface = new AdministratorGraphicalUserInterface(restaurant);
		WaiterGraphicalUserInterface waiterInterface = new WaiterGraphicalUserInterface(restaurant);
		ChefGraphicalUserInterface chefInterface = new ChefGraphicalUserInterface(restaurant);
		restaurant.addObserverToTable(chefInterface);
		Controller controller = new Controller(MainInterface, adminInterface, waiterInterface, chefInterface);
		controller.start();
	}
}