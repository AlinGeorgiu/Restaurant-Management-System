package businessLayer;

import java.io.Serializable;
/**
* @author  Georgiu Alin-Ionel
* @version 1.0
* @since   2020-05-13 
*/
@SuppressWarnings("serial")
public abstract class MenuItem implements Serializable{
	
	private static int count = 0;
	private int id;
	private String name;
	
	public MenuItem(String name) {
		count ++;
		this.id = count;
		this.name = name;
	}
	
	public int getID() {
		return id;
	}
	
	public void setID(int id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String toString(){
		return ("ID : " + id + " " + name);
	}
	/**
	* metoda este de tip abstract si va fi implementata in alte clase care o extind pentru a obtine pretul total
	   */
	public abstract float computePrice();
}
