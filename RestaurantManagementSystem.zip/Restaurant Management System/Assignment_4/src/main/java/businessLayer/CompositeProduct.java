package businessLayer;

import java.util.HashSet;


import java.util.Set;
/**
* @author  Georgiu Alin-Ionel
* @version 1.0
* @since   2020-05-13 
*/
@SuppressWarnings("serial")
public class CompositeProduct extends MenuItem{
	
	private HashSet<MenuItem> productsList;
	
	public CompositeProduct(String name, Set<MenuItem> products) {
		super(name);
		this.productsList = new HashSet<MenuItem>();
		this.productsList = (HashSet<MenuItem>) products;
	}
	
	public Set<MenuItem> getProducts(){
		return productsList;
	}
	
	public void setProducts(Set<MenuItem> productsList) {
		this.productsList = (HashSet<MenuItem>) productsList;
	}
	
	public void addProduct(MenuItem item) {
		productsList.add(item);
	}
	
	public void removeProduct(MenuItem item){
		productsList.remove(item);
	}
	/**
	   * @return retunreaza un float cu suma totala.
	   */
	@Override
	public float computePrice() {
		int total = 0;
		for(MenuItem product : productsList) {
			total += product.computePrice();
		}
		return total;
	}
}
