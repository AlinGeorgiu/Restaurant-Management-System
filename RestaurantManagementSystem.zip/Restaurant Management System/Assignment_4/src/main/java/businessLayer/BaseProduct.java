package businessLayer;

import java.io.Serializable;
/**
 * Clasa care contine un produs din menu
* @author  Georgiu Alin-Ionel
* @version 1.0
* @since   2020-05-13 
*/
@SuppressWarnings("serial")
public class BaseProduct extends MenuItem implements Serializable{
	
	private int price;
	public BaseProduct(String name, int price) {
		super(name);
		this.price = price;
	}
	
	public int getPrice() {
		return price;
	}
	
	public void setPrice(int price) {
		this.price = price;
	}
	
	@Override
	public float computePrice() {
		return price;
	}
}
