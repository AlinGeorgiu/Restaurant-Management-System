package businessLayer;

import java.io.Serializable;
import java.time.LocalDate;
/**
* @author  Georgiu Alin-Ionel
* @version 1.0
* @since   2020-05-13 
*/
@SuppressWarnings("serial")
public class Order implements Serializable{
	
	private static int count = 0;
	private int orderID, table;
	private LocalDate Date;
	
	public Order() {
		count++;
		this.orderID = count;
	}
	
	public int getOrderID() {
		return orderID;
	}
	
	public void setOrderID(int orderID) {
		this.orderID = orderID;
	}
	
	public LocalDate getDate() {
		return this.Date;
	}
	
	public void setDate(LocalDate date) {
		this.Date = LocalDate.now();
	}
	
	public int getTableNumber() {
		return this.table;
	}
	
	public void setTableNumber(int table) {
		this.table = table;
	}
	/**
	*
	   * @return int Returneaza un hashcode pentru ID-ul unei comenzi
	   */
	@Override
	public int hashCode() {
		return orderID;
	}
	
	@Override
	public boolean equals(Object obj) {
		return this == obj;
	}
	
	public String toString() {
		return ("ID : " + orderID + " Nr. table: " + table);
	}
	
}
