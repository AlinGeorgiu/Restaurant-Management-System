package businessLayer;

import java.util.Set;

import presentationLayer.ChefGraphicalUserInterface;
/**
 * Interfata contine metode comune pe care clasa Restaurant le va implementa
* @author  Georgiu Alin-Ionel
* @version 1.0
* @since   2020-05-13 
*/
public interface IRestaurantProcessing {

	public void createNewOrder(Order order, Set<MenuItem> products);

	public void createNewMenuItem(String name, Set<MenuItem> productsList);
	
	public void deleteMenuItem(MenuItem item);
	
	public void editMenuItem(MenuItem oldItem, MenuItem newItem);
	
	public float computeOrderPrice(Order order);
	
	public void generateTableBill(Order order);
	
	public void addObserverToTable(ChefGraphicalUserInterface chefInterface);
}
