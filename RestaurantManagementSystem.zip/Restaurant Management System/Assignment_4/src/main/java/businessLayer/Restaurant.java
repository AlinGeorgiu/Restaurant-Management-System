package businessLayer;

import java.io.Serializable;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Observable;
import java.util.Set;

import dataLayer.FileWriter;
import presentationLayer.ChefGraphicalUserInterface;
/**
* @author  Georgiu Alin-Ionel
* @version 1.0
* @since   2020-05-13 
*/
@SuppressWarnings("deprecation")
public class Restaurant extends Observable implements IRestaurantProcessing, Serializable {

	private HashMap<Order, HashSet<MenuItem>> listOfOrderedProducts;
	private HashSet<MenuItem> menu;

	public Restaurant() {
		listOfOrderedProducts = new HashMap<Order, HashSet<MenuItem>>();
		menu = new HashSet<MenuItem>();
	}

	public void createNewMenuItem(String name, Set<MenuItem> dishes) {
		if (dishes.size() == 1) {
			Iterator<MenuItem> it = dishes.iterator();
			MenuItem item = it.next();
			
			if(item.getID() >= 1) {
				menu.add(item);

			}
			else{
				throw new IllegalStateException();

			}			
			if(menu.contains(item) == false) {
				throw new IllegalStateException();

			}
		} else {
			CompositeProduct item = new CompositeProduct(name, dishes);
			
			if(item.getID() >= 1) {
				menu.add(item);
			}
			else{
				throw new IllegalStateException();
			}

			if(menu.contains(item) == false) {
				throw new IllegalStateException();

			}
		}
	}
	
	public void deleteMenuItem(MenuItem item) {
		if(menu.contains(item) == true) {
			menu.remove(item);
		}
		else
		{
			throw new IllegalStateException();

		}
		if(menu.contains(item) == true) {
			throw new IllegalStateException();

		}
	}
	
	public void addMenuItem(MenuItem item){
		if(item.getID() >= 1) {
			menu.add(item);
		}
		else{
			throw new IllegalStateException();
		}
		
	}
/**	  
 *  * @param oldItem 
	   * @param newItem  
	   */
	public void editMenuItem(MenuItem oldItem, MenuItem newItem) {
		if(menu.contains(oldItem) == true) {
			menu.remove(oldItem);
			menu.add(newItem);
		}
		else {
			throw new IllegalStateException();
		}
		
		if( menu.contains(oldItem) == true)
		{
			throw new IllegalStateException();

		}
	}
	/**	  
	 *  * @param order 
		   * @param products  
		   */
	public void createNewOrder(Order order, Set<MenuItem> products) {
		if(order.getOrderID() >= 1) {
			listOfOrderedProducts.put(order, (HashSet<MenuItem>) products);
		}
		else
		{
			throw new IllegalStateException();

		}
		setChanged();
		notifyObservers();
		if(listOfOrderedProducts.get(order) == null){
			throw new IllegalStateException();
		}
	}
	/**	  
	 *  * @param order 
		   */
	public float computeOrderPrice(Order order) {
		HashSet<MenuItem> items = listOfOrderedProducts.get(order);
		float total = 0;
		if(order.getOrderID() >= 1) {
			for (MenuItem item : items) {
				total += item.computePrice();
			}
		}
		else {
			throw new IllegalStateException();
		}
		return total;
	}
	/**	  
	 *  * @param order 
		   */
	public void generateTableBill(Order order) {
		if(order.getOrderID() <= 0) {
			throw new IllegalStateException();
		}
		else
		{
			FileWriter.generateBill(order, this);
		}
	}
	/**	  
	 * @return boolean Retunreaza true daca e corect format
		   */
	protected boolean wellFormed() {
		Set<MenuItem> menuDishes = new HashSet<MenuItem>();
		int counter = 0;
		for (Order order : listOfOrderedProducts.keySet()) {
			for (MenuItem item : listOfOrderedProducts.get(order)) {
				menuDishes.add(item);
				counter++;
			}
		}
		return menuDishes.size() == counter;
	}
	/**	  
	 *  * @param chefInterface 
	   */
	
	public void addObserverToTable(ChefGraphicalUserInterface chefInterface) {
		this.addObserver(chefInterface);	
	}
	/**	  
	 * 
	 * @param menu 
	   */
	public void setOrderedProducts(Map<Order, HashSet<MenuItem>> menu) {
		this.listOfOrderedProducts = (HashMap<Order, HashSet<MenuItem>>) menu;
	}
	/**	  
	 * 
	 * @return HashMap getOrderedProducts
	   */
	public HashMap<Order, HashSet<MenuItem>> getOrderedProducts() {
		return listOfOrderedProducts;
	}
	/**	  
	 * 
	 * @return menu
	   */
	public HashSet<MenuItem> getMenu() {
		return menu;
	}

	
}
